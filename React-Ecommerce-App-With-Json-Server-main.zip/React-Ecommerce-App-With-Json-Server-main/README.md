# React-Ecommerce-App-With-Josn-Server
* Reactjs
* React-dom-server
* json-server to use fake products api

# Objective
This project was the objective to create an app using Reactjs with json-server to use fake api

# Using
* clone the project
* install all dependency
* install global json-server
* run json:server
* start the app

 cd React-Ecommerce-App-With-Json-Server
 
 
 npm run json:server
 
 
 npm run start
 
 
 Open on your browser http://localhost:3000
