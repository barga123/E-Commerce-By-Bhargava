//** Class Product **//


class Product {

    constructor(id, name, product_info) {
        this.id = id;
        this.name = name;
        this.product_info = product_info;
    }

}

export default Product;